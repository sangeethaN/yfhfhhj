package Classes;

import Interface.Instrument;
import Interface.Performer;

public class Musician implements Performer{
	
	Instrument myfavouriteinstrument;
	public Instrument getMyfavouriteinstrument() {
		return myfavouriteinstrument;
	}
	public void setMyfavouriteinstrument(Instrument myfavouriteinstrument) {
		this.myfavouriteinstrument = myfavouriteinstrument;
	}
	public void perform() {
		myfavouriteinstrument.instrument();
		System.out.println("Musician is performing");
	}
}
