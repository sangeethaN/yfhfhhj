package Classes;

import Interface.Instrument;


public class Veena implements Instrument{

	public void instrument() {
		// TODO Auto-generated method stub
		System.out.println("Instrument name is Veena");
	}

}
