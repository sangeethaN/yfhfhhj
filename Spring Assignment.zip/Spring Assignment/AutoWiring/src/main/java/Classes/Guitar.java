package Classes;

import Interface.Instrument;



public class Guitar implements Instrument{
	
	public void instrument() {
		// TODO Auto-generated method stub
		System.out.println("Instrument is Guitar");
	}

}
