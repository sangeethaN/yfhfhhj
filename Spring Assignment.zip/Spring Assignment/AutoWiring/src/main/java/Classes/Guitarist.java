package Classes;

import org.springframework.beans.factory.annotation.Autowired;

import Interface.Instrument;
import Interface.Performer;

public class Guitarist implements Performer{
	
	@Autowired
	private Instrument myGuitar;
	
	public Instrument getMyGuitar() {
		return myGuitar;
	}

	public void setMyGuitar(Instrument myGuitar) {
		this.myGuitar = myGuitar;
	}
	
	public void perform() {
		// TODO Auto-generated method stub
		myGuitar.instrument();
		System.out.println("Guitarist is performing");
	}

}
