package Classes;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;


@Repository
public class BookDao extends JdbcDaoSupport{
	
	@Autowired
	public BookDao(DataSource dataSource){
		setDataSource(dataSource);
	}
	
	public Book getBookDetails(int id){
		Book book = new Book();
		try{
			book = (Book) getJdbcTemplate().queryForObject("select * from T_XBBNHMH_BookDetails where id = ?", new Object[]{id}, new BookRowMapper());
		}
		catch(Exception e){
			return book;
		}
		return book;
	}
}
