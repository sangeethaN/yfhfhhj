package Classes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class BookController {
	
	@Autowired
	BookDao dao;
	
	@RequestMapping(value="/books/{id}", method=RequestMethod.GET)
	public ModelAndView getBookDetails (@PathVariable int id){
		
		Book book = dao.getBookDetails(id);
		
		// book denotes view Name ==> book.jsp
		//bookTemp is used for mapping the Book bean from spring-servlet.xml ==> model name
		//model Object ==> Autowired book
		System.out.println(book.getId());
		System.out.println(book.getBookName());
		System.out.println(book.getAuthor());
		
		return new ModelAndView("book", "bookTemp", book);
	}
}
