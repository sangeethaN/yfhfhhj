package Classes;

public class Restaurant {
	public void getGroceries() {
		GroceryShop grocery = new GroceryShop();
		grocery.supplyGroceries();
	}

	public void getVegetables() {
		VegetableShop vegetables = new VegetableShop();
		vegetables.supplyVegetables();
	}
}
