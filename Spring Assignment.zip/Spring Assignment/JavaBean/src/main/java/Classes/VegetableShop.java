package Classes;

public class VegetableShop {
	
	public void supplyVegetables(){
		System.out.println("Vegetables  supplied");
	}
}
