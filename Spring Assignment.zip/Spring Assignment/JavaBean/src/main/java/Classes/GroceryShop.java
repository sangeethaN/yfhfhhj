package Classes;

public class GroceryShop {
	
	public void supplyGroceries(){
		System.out.println("Groceries supplied");
	}
}
