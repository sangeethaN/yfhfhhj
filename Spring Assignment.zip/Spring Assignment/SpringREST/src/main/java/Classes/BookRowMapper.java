package Classes;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class BookRowMapper implements RowMapper<Book>{

	public Book mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Book book = new Book();
		book.setId(rs.getInt(1));
		book.setBookName(rs.getString(2));
		book.setAuthor(rs.getString(3));
		return book;
	}

}
