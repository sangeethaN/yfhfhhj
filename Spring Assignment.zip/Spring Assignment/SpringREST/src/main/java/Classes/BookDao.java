package Classes;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;


@Repository
public class BookDao extends JdbcDaoSupport{
	
	@Autowired
	public BookDao(DataSource dataSource){
		setDataSource(dataSource);
	}
	
	public Book getBookDetails(int id){
		try{
			Book book = (Book) getJdbcTemplate().queryForObject("select * from T_XBBNHMH_BookDetails where id = ?", new Object[]{id}, new BookRowMapper());
			return book;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
}
