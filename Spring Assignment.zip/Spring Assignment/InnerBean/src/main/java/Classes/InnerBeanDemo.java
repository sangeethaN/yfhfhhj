package Classes;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Performer;

public class InnerBeanDemo {
	public static void main(String args[]){
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"spring1.xml"});
		Performer instrumentalist = (Performer) appContext.getBean("instrumentalist");
		instrumentalist.perform();
	}
}
