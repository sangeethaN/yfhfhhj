package Classes;

import java.util.Collection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import Interface.Instrument;
import Interface.Performer;

public class OneManBand implements Performer{
	
	private Collection<String> instruments;
	public void perform() {
		// TODO Auto-generated method stub
		Collection<String> instruments = getInstruments();
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"spring2.xml"});
		for(String instrument : instruments){
			Instrument musicInstrument = (Instrument) appContext.getBean(instrument);
			musicInstrument.play();
		}
	}
	
	public Collection<String> getInstruments() {
		return instruments;
	}
	
	public void setInstruments(Collection<String> instruments) {
		this.instruments = instruments;
	}

}
