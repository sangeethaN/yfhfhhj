package Classes;

import Interface.Instrument;

public class Guitar implements Instrument{

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Guitar: pam pam pam");
	}

}
