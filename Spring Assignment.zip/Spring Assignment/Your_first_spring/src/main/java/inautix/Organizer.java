package inautix;

public class Organizer {
void sayGreetings()
{
       System.out.println("Welcome to the talent  competition");
}
}

