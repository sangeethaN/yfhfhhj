package Classes;

import Interface.Instrument;

public class Saxophone implements Instrument{

	public void play() {
		// TODO Auto-generated method stub
		System.out.println("tu tu tu");
	}

}
