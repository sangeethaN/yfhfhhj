package Interface;

public interface Performer {
	public void perform();
}
