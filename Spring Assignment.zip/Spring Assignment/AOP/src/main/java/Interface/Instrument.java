package Interface;

public interface Instrument {
	public void instrument();
}
