package Classes;

import Interface.Instrument;

public class Saxophone implements Instrument{

	public void instrument() {
		// TODO Auto-generated method stub
		System.out.println("Saxophone");
	}

}
