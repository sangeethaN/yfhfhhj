package Classes;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;



@Aspect
public class Audience {
	
    @Before("execution(* Classes.Instrumentalist.perform())")
	public void takeSeats(JoinPoint joinpoint){
		System.out.println("The audience is taking their seats");
	}
}
