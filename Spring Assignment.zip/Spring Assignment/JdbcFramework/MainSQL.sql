set schema sample;

create table T_XBBNHMH_BookDetails(id int primary key, bookName varchar(50), author varchar(50));
insert into T_XBBNHMH_BookDetails values(1, 'The Screaming Staircase', 'Jonathan Stroud');

select * from T_XBBNHMH_BookDetails;