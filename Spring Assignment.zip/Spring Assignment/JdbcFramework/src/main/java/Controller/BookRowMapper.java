package Controller;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class BookRowMapper implements RowMapper<BookDetailsBean>{

	public BookDetailsBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		BookDetailsBean book = new BookDetailsBean();
		book.setId(rs.getInt(1));
		book.setBookName(rs.getString(2));
		book.setAuthor(rs.getString(3));
		return book;
	}

}
