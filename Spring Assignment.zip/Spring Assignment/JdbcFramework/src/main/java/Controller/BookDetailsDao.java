package Controller;
import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

@Repository
public class BookDetailsDao extends JdbcDaoSupport{
	
	@Autowired
	public BookDetailsDao(DataSource dataSource){
		setDataSource(dataSource);
	}
	
	public int createBookDetails(BookDetailsBean book){
		Object[] param = {book.getId(), book.getBookName(), book.getAuthor()};
		int types[] = {Types.INTEGER, Types.VARCHAR, Types.VARCHAR};
		try{
			int numRows = getJdbcTemplate().update("insert into T_XBBNHMH_BookDetails values(?,?,?)", param, types);
			return numRows;
		}
		catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}
	
	public BookDetailsBean getBookDetails(int id){
		try{
			BookDetailsBean book = (BookDetailsBean) getJdbcTemplate().queryForObject("select * from T_XBBNHMH_BookDetails where id = ?", new Object[]{id}, new BookRowMapper());
			return book;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public int updateBookDetails(BookDetailsBean book){
		Object[] param = {book.getBookName(), book.getAuthor(), book.getId()};
		int types[] = {Types.VARCHAR, Types.VARCHAR, Types.INTEGER};
		try{
			int numRows = getJdbcTemplate().update("update T_XBBNHMH_BookDetails set bookName = ?, author = ? where id = ?", param, types);
			return numRows;
		}
		catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}
	
	public int deleteBookDetails(int id){
		try{
			int numRows = getJdbcTemplate().update("delete from T_XBBNHMH_BookDetails where id = ?", new Object[]{id}, new int[]{Types.INTEGER});
			return numRows;
		}
		catch(Exception e){
			return 0;
		}
	}
}
